package chainOfRespon;

import model.User;

public interface BaseRegistro {
	
	boolean processar(User usuario);

}
