package model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TB_Admin")
public class Administrador extends User{
	
	
	
	public Administrador() {
		
	}
}
