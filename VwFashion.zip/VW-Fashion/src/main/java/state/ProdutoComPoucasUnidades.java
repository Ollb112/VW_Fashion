package state;

public class ProdutoComPoucasUnidades implements EstadoProduto {
    private String estadoAtual = "Poucas unidades";
    
	@Override
	public String getStatus() {
        return estadoAtual;
	}

	@Override
	public void setStatus(String estado) {
		estadoAtual = estado;		
	}
}
