package state;

public class ProdutoIndisponivel implements EstadoProduto {
    private String estadoAtual = "Indisponivel";

	public String getStatus() {
        return estadoAtual;
	}

	@Override
	public void setStatus(String estado) {
		estadoAtual = estado;		
	}
}