package state;

public interface EstadoProduto {
    String getStatus();
    void setStatus(String estado);

}
