package state;

public class ProdutoDisponivel implements EstadoProduto {
    private String estadoAtual = "Disponivel";
    
	public String getStatus() {
        return estadoAtual;
	}

	@Override
	public void setStatus(String estado) {
		estadoAtual = estado;		
	}
}
