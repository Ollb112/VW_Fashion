package controller;

import java.awt.event.ActionEvent;

import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionListener;
import javax.faces.event.ActionListenerWrapper;

public class OuvinteListagem implements ActionListener{

	@Override
	public void processAction(javax.faces.event.ActionEvent event) throws AbortProcessingException {
		// TODO Auto-generated method stub
		
	}

	



}
