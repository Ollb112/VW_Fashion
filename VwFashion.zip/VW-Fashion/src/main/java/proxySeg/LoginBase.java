package proxySeg;

import model.User;

public interface LoginBase {
	
	public User fazerLogin(String email, String senha);

}
