package memento;

import java.util.Date;

public class UserMemento {
    private final String email;
    private final String nome;
    private final Date nascimento;
    private final String senha;

    public UserMemento(String email, String nome, Date nascimento, String senha) {
        this.email = email;
        this.nome = nome;
        this.nascimento = nascimento;
        this.senha = senha;
    }

    // Getters para os campos
    public String getEmail() {
        return email;
    }

    public String getNome() {
        return nome;
    }

    public Date getNascimento() {
        return nascimento;
    }

    public String getSenha() {
        return senha;
    }
}
