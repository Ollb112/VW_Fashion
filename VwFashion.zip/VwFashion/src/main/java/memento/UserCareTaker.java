package memento;

public class UserCareTaker {
    private UserMemento memento;

    public void salvarMemento(UserMemento memento) {
        this.memento = memento;
    }

    public UserMemento getUltimoMementoSalvo() {
        return memento;
    }
}
