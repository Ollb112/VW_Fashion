package memento;

public class ProdutoMemento {
    private final long idProduto;
    private final float preco;
    private final String marca;
    private final String nomeProduto;
    private final int quantidade;

    public ProdutoMemento(long idProduto, float preco, String marca, String nomeProduto, int quantidade) {
        this.idProduto = idProduto;
        this.preco = preco;
        this.marca = marca;
        this.nomeProduto = nomeProduto;
        this.quantidade = quantidade;
    }

    // Getters para os campos
    public long getIdProduto() {
        return idProduto;
    }

    public float getPreco() {
        return preco;
    }

    public String getMarca() {
        return marca;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public int getQuantidade() {
        return quantidade;
    }
}

