package memento;

public class ProdutoCareTaker {
    private ProdutoMemento memento;

    public void salvarMemento(ProdutoMemento memento) {
        this.memento = memento;
    }

    public ProdutoMemento getUltimoMementoSalvo() {
        return memento;
    }
}
