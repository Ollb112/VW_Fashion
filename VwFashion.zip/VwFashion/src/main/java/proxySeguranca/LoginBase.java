package proxySeguranca;

import model.User;

public interface LoginBase {
	
	public void fazerLogin(String email, String senha);

}
