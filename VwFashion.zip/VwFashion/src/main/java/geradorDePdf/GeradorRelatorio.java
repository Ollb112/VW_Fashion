package geradorDePdf;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import model.Pedido;
import model.Produto;

public class GeradorRelatorio {
	@SuppressWarnings("deprecation")
	public void gerarRelatorioMensal(Month m, ArrayList<Pedido> pedidos) {
	    Document doc = new Document(PageSize.A4);
	    
	    try {
	        FileOutputStream os = new FileOutputStream("relatorio.pdf");
	        PdfWriter.getInstance(doc, os);
	        
	        doc.open();
	        
	        PdfPTable table = new PdfPTable(4); // Criando uma tabela com 4 colunas
	        table.setWidthPercentage(100); // Define a largura da tabela
	        
	        // Cabeçalhos da tabela
	        table.addCell("ID do Pedido");
	        table.addCell("Produtos");
	        table.addCell("Preço");
	        table.addCell("Valor Total");
	        
	        double valorTotal = 0;
	        
	        for (Pedido p : pedidos) {
	            if (m.getValue() == p.getData().getMonth()) {
	                // Adicionando dados na tabela para cada pedido
	                table.addCell(String.valueOf(p.getIdPedido()));
	                table.addCell(getProdutosString(p.getProdutos()));
	                table.addCell(getPrecosString(p.getProdutos()));
	                table.addCell(String.valueOf(p.getValorTotal()));
	                
	                // Somando o valor total apenas para os pedidos do mês
	                valorTotal += p.getValorTotal();
	            }
	        }
	        
	        // Adicionando célula vazia para a última linha (antes do valor total)
	        table.addCell("");
	        table.addCell("");
	        table.addCell("");
	        
	        // Adicionando o valor total na última linha
	        table.addCell("Total:");
	        table.addCell("");
	        table.addCell("");
	        table.addCell(String.valueOf(valorTotal));
	        
	        // Adicionando a tabela ao documento
	        doc.add(table);
	        
	        doc.close();
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (DocumentException e) {
	        e.printStackTrace();
	    }
	}

	// Método para obter a representação dos produtos como String
	private String getProdutosString(List<Produto> produtos) {
	    StringBuilder produtosString = new StringBuilder();
	    for (Produto produto : produtos) {
	        produtosString.append(produto.getNome_produto()).append("\n");
	    }
	    return produtosString.toString();
	}

	// Método para obter a representação dos preços dos produtos como String
	private String getPrecosString(List<Produto> produtos) {
	    StringBuilder precosString = new StringBuilder();
	    for (Produto produto : produtos) {
	        precosString.append(produto.getPreco()).append("\n");
	    }
	    return precosString.toString();
	}
    public byte[] gerarRelatorioMensalEmail(Month m, ArrayList<Pedido> pedidos) {
        Document doc = new Document(PageSize.A4);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        
        try {
            PdfWriter.getInstance(doc, byteArrayOutputStream);
            
            doc.open();
            
            PdfPTable table = new PdfPTable(4); // Criando uma tabela com 4 colunas
            table.setWidthPercentage(100); // Define a largura da tabela
            
            // Restante do código para preencher a tabela...

            // Adicionando a tabela ao documento
            doc.add(table);
            
            doc.close();
        } catch (DocumentException e) {
            e.printStackTrace();
        }
        
        return byteArrayOutputStream.toByteArray();
    }

    // Métodos getProdutosString e getPrecosString permanecem os mesmos...

}
