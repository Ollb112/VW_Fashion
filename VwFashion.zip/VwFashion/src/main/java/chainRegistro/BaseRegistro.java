package chainRegistro;

import model.User;

public interface BaseRegistro {
	
	boolean processar(User usuario);

}
