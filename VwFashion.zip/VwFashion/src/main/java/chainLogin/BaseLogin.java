package chainLogin;



public interface BaseLogin {
	
	boolean processar(String email, String senha);

}
