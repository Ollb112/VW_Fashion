package dto;

public record ProdutoDTO(long idProduto, float preco, String marca, String nomeProduto, int quantidade) {

   
}
