package dto;

import java.io.Serializable;
import java.util.Date;

public record UserDTO(String email, String nome, Date nascimento, String senha) {
    
}
