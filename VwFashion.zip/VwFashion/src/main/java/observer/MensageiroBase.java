package observer;

public interface MensageiroBase {
	
	public void enviarEmail(String assunto, String mensagem);

}
