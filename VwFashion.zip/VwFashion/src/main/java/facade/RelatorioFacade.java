package facade;
import javax.mail.util.ByteArrayDataSource;

import java.time.Month;
import java.util.ArrayList;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.MultiPartEmail;
import geradorDePdf.GeradorRelatorio;
import model.Pedido;

public class RelatorioFacade {
    public void gerarRelatorioEMail(Month mes, ArrayList<Pedido> pedidos, String endereco) {
        GeradorRelatorio gR = new GeradorRelatorio();
        byte[] relatorio = gR.gerarRelatorioMensalEmail(mes, pedidos);
        
        enviarRelatorioPorEmail(endereco, "Relatório Mensal", relatorio);
    }

    private void enviarRelatorioPorEmail(String endereco, String assunto, byte[] relatorio) {
        try {
            MultiPartEmail email = new MultiPartEmail();
            email.setHostName("smtp.gmail.com");
            email.setAuthentication("seuemail@gmail.com", "suaSenha");
            email.setSSLOnConnect(true);
            email.addTo(endereco);
            email.setFrom("seuemail@gmail.com");
            email.setSubject(assunto);

            // Anexando o PDF ao e-mail
            email.attach(new ByteArrayDataSource(relatorio, "application/pdf"), "relatorio.pdf", "Relatório Mensal");

            // Enviando o e-mail
            email.send();
        } catch (EmailException ex) {
            ex.printStackTrace();
        }
    }
}
